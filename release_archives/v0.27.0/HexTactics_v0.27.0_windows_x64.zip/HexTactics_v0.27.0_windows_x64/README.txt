HexTactics v0.27.0 - Windows x64

Run: HexTactics.exe (keep the data_HexTactics_windows_x86_64 folder and HexTactics.pck next to it).
HexTactics.console.exe starts the same game with a console window that shows the log.
No installation and no .NET installation required.
Release notes: docs/releases/v0.27.0/README.md in the source repository.
Build: see BUILD_INFO.txt
